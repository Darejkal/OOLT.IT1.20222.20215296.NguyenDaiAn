package hust.soict.it1.StudentManage.exceptions;
public class IllegalGPAException extends Exception {
    public IllegalGPAException() {
    	super();
    }
}
