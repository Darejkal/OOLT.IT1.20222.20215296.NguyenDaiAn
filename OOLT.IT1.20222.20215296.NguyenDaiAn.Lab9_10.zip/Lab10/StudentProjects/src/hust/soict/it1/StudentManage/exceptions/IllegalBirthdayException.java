package hust.soict.it1.StudentManage.exceptions;
public class IllegalBirthdayException extends Exception {
    public IllegalBirthdayException() {
    	super();
    }
}
