package hust.soict.it1.aims;
public class PlayerException extends Exception {
    public PlayerException() {
    	super();
    }
}
