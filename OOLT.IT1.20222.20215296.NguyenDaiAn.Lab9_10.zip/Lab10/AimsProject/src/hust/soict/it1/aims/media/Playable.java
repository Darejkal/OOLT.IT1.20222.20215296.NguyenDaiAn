package hust.soict.it1.aims.media;

import hust.soict.it1.aims.PlayerException;

public interface Playable {
    public void play() throws PlayerException;
}
