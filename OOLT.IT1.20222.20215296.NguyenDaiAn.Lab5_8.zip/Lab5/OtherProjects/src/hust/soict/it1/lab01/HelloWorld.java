package hust.soict.it1.lab01;
// Exercise 1
public class HelloWorld {
    public static void main(String[] args){
        System.out.println("Xin chao \n cac ban!");
        System.out.println("Hello \t world");
    }
}